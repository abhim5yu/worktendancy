# Attendance (Android app + home screen widget)

1. Create a new private repo on GitHub and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on push. You can also run it with "Run workflow".
3. When it finishes, open the run and download the **attendance-apk** artifact. Unzip it to get `app-debug.apk`.
4. Install the APK on your phone (allow installs from your browser or file manager).
5. Move your data: in the old web app go to Settings > Backup > Edit > Copy backup. In the new app go to Settings > Backup > Edit, paste, and tap Restore.
6. Long press the home screen > Widgets > Attendance and drop it on the home screen.

The widget shows the clock (green before your late time, red after), today's status, this month's percentage and your streak.
Present and Absent on the widget open the app and mark today. The widget refreshes whenever you open the app.
