package com.attendance.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AttendanceWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refresh(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) refresh(context)
    }

    companion object {
        const val ACTION_REFRESH = "com.attendance.app.REFRESH"

        fun refresh(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, AttendanceWidget::class.java))
            if (ids.isNotEmpty()) {
                val views = build(context)
                for (id in ids) mgr.updateAppWidget(id, views)
            }
            schedule(context)
        }

        private fun summary(c: Context): JSONObject {
            val raw = c.getSharedPreferences("att", Context.MODE_PRIVATE).getString("summary", null)
            return try { JSONObject(raw ?: "{}") } catch (_: Exception) { JSONObject() }
        }

        private fun lum(c: Int) = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000

        private fun open(c: Context, mark: String?, code: Int): PendingIntent {
            val i = Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (mark != null) i.putExtra("mark", mark)
            return PendingIntent.getActivity(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun build(c: Context): RemoteViews {
            val bg = c.getSharedPreferences("att", Context.MODE_PRIVATE).getInt("bg", Color.BLACK)
            val dark = lum(bg) < 128
            val ink = if (dark) Color.WHITE else Color.BLACK
            val mute = Color.parseColor("#8E8E8E")

            var pct = -1
            var streak = 0
            var cut = 540
            var accent = ink
            var status = "Open the app once to set up"
            val o = summary(c)
            if (o.has("pct")) {
                pct = o.optInt("pct", -1)
                streak = o.optInt("streak", 0)
                cut = o.optInt("cut", 540)
                val a = o.optString("ac", "")
                if (a.startsWith("#")) try { accent = Color.parseColor(a) } catch (_: Exception) {}
                val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                status = if (o.optString("day") == today) o.optString("status") else "Tap to open and update"
            }

            val cal = Calendar.getInstance()
            val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            val late = nowMin > cut
            val timeColor = when {
                late && dark -> Color.parseColor("#FF5A52")
                late -> Color.parseColor("#E5322D")
                dark -> Color.parseColor("#35D07F")
                else -> Color.parseColor("#10A152")
            }
            val onAccent = if (lum(accent) > 150) Color.BLACK else Color.WHITE

            val v = RemoteViews(c.packageName, R.layout.widget)
            v.setInt(R.id.root, "setBackgroundResource", if (dark) R.drawable.wbg_dark else R.drawable.wbg_light)
            v.setTextColor(R.id.clk, timeColor)
            v.setTextColor(R.id.ampm, timeColor)
            v.setTextViewText(R.id.status, status)
            v.setTextColor(R.id.status, mute)
            v.setTextViewText(R.id.pct, if (pct < 0) "–" else "$pct%")
            v.setTextColor(R.id.pct, ink)
            v.setTextColor(R.id.pctlabel, mute)
            v.setTextViewText(R.id.streak, streak.toString())
            v.setTextColor(R.id.streak, ink)
            v.setInt(R.id.flame, "setColorFilter", accent)
            v.setInt(R.id.pillP, "setColorFilter", accent)
            v.setInt(R.id.pillA, "setColorFilter", accent)
            v.setTextColor(R.id.tP, onAccent)
            v.setTextColor(R.id.tA, onAccent)
            v.setOnClickPendingIntent(R.id.root, open(c, null, 0))
            v.setOnClickPendingIntent(R.id.bP, open(c, "P", 1))
            v.setOnClickPendingIntent(R.id.bA, open(c, "A", 2))
            return v
        }

        // Re-render once the late time passes and again after midnight.
        private fun schedule(c: Context) {
            val cut = summary(c).optInt("cut", 540)
            val now = System.currentTimeMillis()
            val base = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val lateAt = base + (cut + 1) * 60_000L
            val midnight = base + 24 * 3_600_000L + 60_000L
            val at = if (lateAt > now) lateAt else midnight
            val pi = PendingIntent.getBroadcast(
                c, 9,
                Intent(c, AttendanceWidget::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).set(AlarmManager.RTC, at, pi)
        }
    }
}
