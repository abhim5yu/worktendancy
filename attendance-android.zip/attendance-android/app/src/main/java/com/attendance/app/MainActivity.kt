package com.attendance.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var pendingMark: String? = null
    private var loaded = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("att", MODE_PRIVATE)
        val bg = prefs.getInt("bg", Color.BLACK)
        applyBars(bg)

        web = WebView(this)
        web.setBackgroundColor(bg)
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView, url: String) {
                loaded = true
                runPending()
            }
        }

        pendingMark = intent.getStringExtra("mark")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingMark = intent.getStringExtra("mark")
        runPending()
    }

    private fun runPending() {
        val m = pendingMark ?: return
        if (!loaded) return
        pendingMark = null
        web.evaluateJavascript("window.quickMark && quickMark('$m')", null)
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun lum(c: Int) = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000

    private fun applyBars(bg: Int) {
        window.statusBarColor = bg
        window.navigationBarColor = bg
        var flags = 0
        if (lum(bg) > 150) {
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
    }

    private fun parseBg(s: String): Int? {
        val n = Regex("\\d+").findAll(s).map { it.value.toInt() }.toList()
        return if (n.size >= 3) Color.rgb(n[0], n[1], n[2]) else null
    }

    inner class Bridge {
        @JavascriptInterface
        fun sync(json: String) {
            val prefs = getSharedPreferences("att", MODE_PRIVATE)
            val ed = prefs.edit().putString("summary", json)
            var bg: Int? = null
            try { bg = parseBg(JSONObject(json).optString("bg")) } catch (_: Exception) {}
            if (bg != null) ed.putInt("bg", bg)
            ed.apply()
            if (bg != null) runOnUiThread {
                applyBars(bg)
                web.setBackgroundColor(bg)
            }
            AttendanceWidget.refresh(this@MainActivity)
        }
    }
}
