package com.attendance.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Reminders.schedule(context)
            AttendanceWidget.refresh(context)
            return
        }
        val kind = intent.getStringExtra("kind") ?: return
        Reminders.fire(context, kind)
        Reminders.schedule(context)
    }
}

object Reminders {
    private const val CH = "reminders"
    private const val ACT = "com.attendance.app.REMIND"

    private fun summary(c: Context): JSONObject {
        val raw = c.getSharedPreferences("att", Context.MODE_PRIVATE).getString("summary", null)
        return try { JSONObject(raw ?: "{}") } catch (_: Exception) { JSONObject() }
    }

    private fun pending(c: Context, code: Int, kind: String): PendingIntent =
        PendingIntent.getBroadcast(
            c, code,
            Intent(c, ReminderReceiver::class.java).setAction(ACT).putExtra("kind", kind),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun schedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c, 1, "in"))
        am.cancel(pending(c, 2, "out"))
        val rem = summary(c).optJSONObject("rem") ?: return
        if (!rem.optBoolean("on")) return
        at(c, am, 1, "in", rem.optInt("i", 540))
        at(c, am, 2, "out", rem.optInt("o", 1080))
    }

    private fun at(c: Context, am: AlarmManager, code: Int, kind: String, minute: Int) {
        val t = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minute / 60); set(Calendar.MINUTE, minute % 60)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (t.timeInMillis <= System.currentTimeMillis()) t.add(Calendar.DAY_OF_YEAR, 1)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.timeInMillis, pending(c, code, kind))
    }

    fun fire(c: Context, kind: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) return
        val o = summary(c)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val fresh = o.optString("day") == today
        val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
        val off = o.optJSONArray("off")
        if (off != null) for (i in 0 until off.length()) if (off.optInt(i) == dow) return

        val title: String
        val text: String
        if (kind == "in") {
            if (fresh && (o.optBoolean("marked") || o.optBoolean("leave"))) return
            title = "Check in"
            text = "Mark your attendance for today."
        } else {
            if (!fresh || !o.optBoolean("work") || o.optBoolean("out")) return
            title = "Check out"
            text = "Don't forget to check out."
        }

        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder = if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Reminders", NotificationManager.IMPORTANCE_DEFAULT))
            Notification.Builder(c, CH)
        } else {
            Notification.Builder(c)
        }
        val open = PendingIntent.getActivity(
            c, 3,
            Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        b.setSmallIcon(R.drawable.ic_flame).setContentTitle(title).setContentText(text)
            .setAutoCancel(true).setContentIntent(open)
        nm.notify(if (kind == "in") 11 else 12, b.build())
    }
}
